<?php
    echo "Aqui está o codigo PHP.";
?>